import React, { useState, useMemo, useEffect } from 'react';
import { 
  Tooltip as RechartsTooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import { 
  Building2, TrendingUp, TrendingDown, Target, Database, Search, 
  ArrowLeft, RefreshCw, Calendar, DollarSign,
  Zap, Activity, Crosshair, ChevronDown, ChevronUp,
  PieChart as PieChartIcon, CheckCircle, AlertCircle
} from 'lucide-react';

// Your provided Google Sheet ID
const SHEET_ID = '1gJN_CV3FrC9omcPxCBqaYYWJa7DCnv8_aFoeMMteOgI';
const TRANSACTIONS_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&sheet=transaction`;
const VILLAS_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&sheet=villas`;

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#06B6D4', '#64748B'];

// Fail-safe CSV Parser
const parseCSV = (str) => {
  const arr = [];
  let quote = false;
  let row = [], col = '';
  for (let c = 0; c < str.length; c++) {
    let cc = str[c], nc = str[c+1];
    if (cc === '"' && quote && nc === '"') { col += cc; ++c; continue; }
    if (cc === '"') { quote = !quote; continue; }
    if (cc === ',' && !quote) { row.push(col.trim()); col = ''; continue; }
    if (cc === '\r' && nc === '\n' && !quote) { row.push(col.trim()); arr.push(row); col = ''; row = []; ++c; continue; }
    if (cc === '\n' && !quote) { row.push(col.trim()); arr.push(row); col = ''; row = []; continue; }
    if (cc === '\r' && !quote) { row.push(col.trim()); arr.push(row); col = ''; row = []; continue; }
    col += cc;
  }
  if (col || row.length > 0) {
      row.push(col.trim());
      arr.push(row);
  }
  return arr.filter(r => r.some(cell => cell !== '')); 
};

// Bulletproof number cleaner
const cleanNumber = (val) => {
  if (val === undefined || val === null) return 0;
  const cleaned = String(val).replace(/[^0-9.-]+/g, "");
  const num = parseFloat(cleaned);
  return isNaN(num) ? 0 : num;
};

export default function App() {
  const [rawData, setRawData] = useState([]);
  const [villasData, setVillasData] = useState([]);
  const [isFetching, setIsFetching] = useState(true); 
  const [syncStatus, setSyncStatus] = useState('Syncing Data...');
  const [fetchError, setFetchError] = useState(null);
  
  const [viewMode, setViewMode] = useState('overview'); 
  const [currencyFormat, setCurrencyFormat] = useState('default'); 
  const [searchTerm, setSearchTerm] = useState('');
  
  const [logTypeFilter, setLogTypeFilter] = useState('All');
  const [logCategoryFilter, setLogCategoryFilter] = useState('All');
  
  const [dateRange, setDateRange] = useState('All'); 
  const [showSearchPopup, setShowSearchPopup] = useState(false);
  const [tempSearchInput, setTempSearchInput] = useState('');
  const [showYearAccordion, setShowYearAccordion] = useState(false);
  const [expandedYear, setExpandedYear] = useState(null);

  const fetchLiveSheetData = async () => {
    setIsFetching(true);
    setFetchError(null);
    setSyncStatus('Connecting to Google Sheets...');
    
    try {
      // 1. Fetch Transactions
      setSyncStatus('Fetching Transactions...');
      const transRes = await fetch(TRANSACTIONS_URL, { cache: 'no-store' });
      if (!transRes.ok) throw new Error(`HTTP Error ${transRes.status}: Cannot reach Transaction Sheet.`);
      const transText = await transRes.text();
      
      if (transText.trim().startsWith('<')) {
         throw new Error("Sheet returned HTML instead of Data. Please check if your tab name is EXACTLY 'transaction' in Google Sheets.");
      }

      const transCsv = parseCSV(transText);
      const parsedTransactions = [];
      let idCounter = 1;
      
      const transRows = transCsv.slice(1);
      transRows.forEach(row => {
        if (!row || row.length < 4) return;
        
        const type = row[0] ? row[0].trim() : 'Unknown';
        const category = row[1] ? row[1].trim() : 'Uncategorized';
        const payeeName = row[2] ? row[2].trim() : 'Unknown Payee';
        
        const total = cleanNumber(row[3]);
        const p1 = cleanNumber(row[4]);
        const p2 = cleanNumber(row[5]);

        if (total === 0 && p1 === 0 && p2 === 0) return;

        if (p1 === 0 && p2 === 0) {
           parsedTransactions.push({ id: idCounter++, type, category, payeeName, amount: total, date: '2025-01-15' });
        } else {
           if (p1 > 0) {
              const p1Monthly = p1 / 6;
              const p1Months = ['2026-04-15', '2026-05-15', '2026-06-15', '2026-07-15', '2026-08-15', '2026-09-15'];
              p1Months.forEach(d => parsedTransactions.push({ id: idCounter++, type, category, payeeName, amount: p1Monthly, date: d }));
           }
           if (p2 > 0) {
              const p2Monthly = p2 / 12;
              const p2Months = ['2025-04-15', '2025-05-15', '2025-06-15', '2025-07-15', '2025-08-15', '2025-09-15', '2025-10-15', '2025-11-15', '2025-12-15', '2026-01-15', '2026-02-15', '2026-03-15'];
              p2Months.forEach(d => parsedTransactions.push({ id: idCounter++, type, category, payeeName, amount: p2Monthly, date: d }));
           }
        }
      });
      
      if(parsedTransactions.length === 0) {
         throw new Error("Transaction sheet loaded, but no valid data rows found. Check your columns.");
      }
      setRawData(parsedTransactions);

      // 2. Fetch Villas
      setSyncStatus('Fetching Inventory & Client Ledgers...');
      const villasRes = await fetch(VILLAS_URL, { cache: 'no-store' });
      if (!villasRes.ok) throw new Error(`HTTP Error ${villasRes.status}: Cannot reach Villas Sheet.`);
      const villasText = await villasRes.text();
      
      if (villasText.trim().startsWith('<')) {
         throw new Error("Sheet returned HTML instead of Data. Please check if your tab name is EXACTLY 'villas' in Google Sheets.");
      }

      const villasCsv = parseCSV(villasText);
      const parsedVillas = [];
      const villasRows = villasCsv.slice(1);
      
      villasRows.forEach((row, index) => {
        if (!row || row.length < 3) return;
        const atsValue = cleanNumber(row[4]);
        const amount = cleanNumber(row[5]);
        const balance = cleanNumber(row[6]);
        
        if (atsValue === 0 && amount === 0 && balance === 0 && !row[1] && !row[2]) return;

        parsedVillas.push({
           sr: row[0] || index + 1,
           client: row[1] || 'Unknown Client',
           villa: row[2] || '-',
           type: row[3] || 'N/A',
           atsValue,
           amount,
           balance,
           status: row[7] || 'Unknown'
        });
      });
      setVillasData(parsedVillas);
      setSyncStatus('Complete!');
      
    } catch (error) {
      console.error("Dashboard Fetch Error:", error);
      setFetchError(error.message);
    } finally {
      setTimeout(() => setIsFetching(false), 800);
    }
  };

  useEffect(() => {
    fetchLiveSheetData();
  }, []);

  const formatCurrency = (value) => {
    if (!value || value === 0) return '₹ 0';
    let formatted = value;
    let suffix = '';
    
    if (currencyFormat === 'lakhs') {
      formatted = (value / 100000).toFixed(2);
      suffix = ' L';
    } else if (currencyFormat === 'crores') {
      formatted = (value / 10000000).toFixed(2);
      suffix = ' Cr';
    } else {
      return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);
    }
    return `₹ ${formatted}${suffix}`;
  };

  const isDateInRange = (dateString, rangeString) => {
    if (rangeString === 'All' || !rangeString) return true;
    if (!dateString) return false;
    
    const [year, month] = dateString.split('-');
    const dateObj = new Date(dateString);
    const monthName = dateObj.toLocaleString('en-US', { month: 'short' });
    
    const query = rangeString.toLowerCase();
    if (query.includes(year)) return true;
    if (query.includes('2025') && year === '2025') return true;
    if (query.includes('2026') && year === '2026') return true;
    if (query.includes(monthName.toLowerCase()) && query.includes(year)) return true;
    return query.includes('all') ? true : false;
  };

  const processedData = useMemo(() => {
    let inflow = 0; let outflow = 0; let refunds = 0;
    const categoryTotals = {};
    let filteredTrx = [];

    rawData.forEach(item => {
      if (!isDateInRange(item.date, dateRange)) return;
      const amount = item.amount || 0;
      filteredTrx.push({ ...item, currentAmount: amount });

      if (item.type === 'Revenue') inflow += amount;
      else if (item.type === 'Refund') { refunds += amount; outflow += amount; } 
      else if (item.type === 'Expense') outflow += amount;

      if (item.category !== 'Collection' && item.category !== 'Refund') {
         categoryTotals[item.category] = (categoryTotals[item.category] || 0) + amount;
      }
    });

    const netPosition = inflow - outflow;
    const marketingExpenses = categoryTotals['Sales & Marketing'] || 0;
    const totalSoldVillas = villasData.filter(v => v.status === 'Sold Out' || v.status === 'Sold').length || 1;
    const costPerVilla = marketingExpenses / totalSoldVillas;
    
    const avgMonthlyBurn = outflow / 12; 
    const cashRunway = netPosition > 0 && avgMonthlyBurn > 0 ? (netPosition / avgMonthlyBurn).toFixed(1) : 0;

    const breakdownData = Object.entries(categoryTotals)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);

    if (logTypeFilter !== 'All') {
       filteredTrx = filteredTrx.filter(t => t.type === logTypeFilter);
    }
    if (logCategoryFilter !== 'All') {
       filteredTrx = filteredTrx.filter(t => t.category === logCategoryFilter);
    }
    if (searchTerm) {
       filteredTrx = filteredTrx.filter(t => 
         (t.payeeName || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
         (t.category || '').toLowerCase().includes(searchTerm.toLowerCase())
       );
    }

    return { 
      inflow, outflow, refunds, netPosition, 
      costPerVilla, avgMonthlyBurn, cashRunway,
      breakdownData, 
      transactions: filteredTrx.sort((a, b) => b.currentAmount - a.currentAmount) 
    };
  }, [rawData, villasData, dateRange, logTypeFilter, logCategoryFilter, searchTerm]);

  const filteredVillas = useMemo(() => {
    return villasData.filter(villa => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = (villa.client || '').toLowerCase().includes(searchLower) || 
                            (villa.villa || '').toString().includes(searchLower);
      return matchesSearch;
    });
  }, [villasData, searchTerm]);

  const villaStats = useMemo(() => {
     const totalUnits = villasData.length;
     const soldOutUnits = villasData.filter(v => v.status === 'Sold Out' || v.status === 'Sold').length;
     
     const masterLedgerInflow = processedData.inflow; 
     
     let filteredReceived = 0;
     let filteredBalance = 0;
     let filteredAts = 0;
     
     filteredVillas.forEach(villa => {
        let ratio = 1; 
        if (dateRange !== 'All') {
            ratio = (masterLedgerInflow > 0 && villa.amount > 0) ? (villa.amount / masterLedgerInflow) : 0;
            if(ratio > 1) ratio = 1;
        }
        filteredReceived += dateRange === 'All' ? villa.amount : (masterLedgerInflow * ratio);
        filteredBalance += villa.balance;
        filteredAts += villa.atsValue;
     });
     
     const collectionProgress = filteredAts > 0 ? ((filteredReceived / filteredAts) * 100).toFixed(1) : 0;
     return { totalUnits, soldOutUnits, totalCollected: filteredReceived, totalAts: filteredAts, totalBalance: filteredBalance, collectionProgress, masterLedgerInflow };
  }, [villasData, filteredVillas, dateRange, processedData.inflow]);

  // Loading Screen
  if (isFetching && !fetchError) {
    return (
      <div className="h-screen w-full bg-[#0a0f1c] flex flex-col items-center justify-center text-blue-400 font-sans relative">
        <div className="relative">
           <RefreshCw className="w-12 h-12 animate-spin mb-6 text-blue-500 drop-shadow-[0_0_15px_rgba(59,130,246,0.8)]" />
           <div className="absolute inset-0 w-12 h-12 rounded-full border-t-2 border-transparent border-l-2 border-emerald-400 animate-ping opacity-50"></div>
        </div>
        <h2 className="text-xl font-bold tracking-widest animate-pulse mb-2 text-white drop-shadow-md">CONNECTING TO SHEETS</h2>
        <p className="text-xs text-slate-400 uppercase tracking-widest">{syncStatus}</p>
      </div>
    );
  }

  // Exact Error Diagnostic Screen
  if (fetchError) {
    return (
      <div className="h-screen w-full bg-[#0a0f1c] flex flex-col items-center justify-center text-rose-400 font-sans p-6 text-center">
        <AlertCircle className="w-16 h-16 mb-4 text-rose-500 animate-bounce" />
        <h2 className="text-2xl font-bold mb-2 text-white">Data Connection Failed</h2>
        <div className="bg-rose-950/50 p-5 rounded-xl border border-rose-900/50 mb-6 max-w-xl text-sm text-rose-200 shadow-[0_0_20px_rgba(225,29,72,0.2)]">
           <p className="font-mono mb-4 bg-black/30 p-2 rounded">{fetchError}</p>
           <p className="text-slate-400 text-xs leading-relaxed text-left">
             <strong className="text-white">Quick Check Fixes:</strong><br/>
             1. Open your Google Sheet and look at the tab names at the bottom.<br/>
             2. They must be spelled EXACTLY as <strong className="text-blue-300">transaction</strong> and <strong className="text-blue-300">villas</strong> (All lowercase, no spaces).<br/>
             3. Ensure your columns aren't completely empty.<br/>
             4. Make sure sharing is set to "Anyone with the link can view".
           </p>
        </div>
        <button onClick={fetchLiveSheetData} className="px-6 py-2.5 bg-rose-600 text-white font-bold rounded-lg hover:bg-rose-500 shadow-lg shadow-rose-600/20 transition-all flex items-center gap-2">
           <RefreshCw size={16} /> Try Connection Again
        </button>
      </div>
    );
  }

  return (
    <div className="h-screen w-full bg-gradient-to-br from-[#0f172a] via-[#0b1120] to-[#020617] p-2 md:p-3 flex flex-col overflow-hidden text-slate-200 font-sans relative">
      <style>{`
        .custom-scroll::-webkit-scrollbar { width: 4px; height: 4px; }
        .custom-scroll::-webkit-scrollbar-track { background: rgba(30, 41, 59, 0.2); border-radius: 4px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: rgba(51, 65, 85, 0.8); border-radius: 4px; }
        .panel-3d { background: rgba(15, 23, 42, 0.4); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.05); box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.05); }
        .btn-3d { background: linear-gradient(145deg, #1e293b, #0f172a); box-shadow: 2px 2px 5px rgba(0,0,0,0.4), -1px -1px 3px rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.05); }
        .btn-3d:active { box-shadow: inset 2px 2px 5px rgba(0,0,0,0.5); }
      `}</style>

      {/* --- HEADER --- */}
      <header className="flex-shrink-0 flex justify-between items-center mb-3">
        <div>
          <h1 className="text-lg md:text-xl font-bold flex items-center gap-2 drop-shadow-md text-white">
            <Building2 className="text-blue-500" size={20} /> The Heritage, Narsinghpura
          </h1>
          <div className="text-[10px] md:text-xs text-emerald-400 flex items-center gap-1 mt-0.5">
            <CheckCircle size={12} className="text-emerald-500" /> Live Data Attached
          </div>
        </div>

        <div className="flex items-center gap-2">
          {viewMode === 'villas' && (
             <button onClick={() => setViewMode('overview')} className="btn-3d flex items-center gap-1.5 px-3 py-1.5 text-white rounded-lg text-xs font-semibold hover:text-blue-400">
                <ArrowLeft size={14} /> Back to Overview
             </button>
          )}

          {viewMode === 'overview' && (
            <>
              <button onClick={fetchLiveSheetData} className="btn-3d flex items-center gap-1.5 px-3 py-1.5 text-slate-300 rounded-lg text-xs font-semibold hover:text-purple-400">
                <RefreshCw size={12} /> Sync Sheets
              </button>

              <div className="relative group z-50">
                <button className="btn-3d flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-amber-400">
                  <DollarSign size={14} /> {currencyFormat === 'default' ? '₹' : currencyFormat === 'lakhs' ? '(L)' : '(Cr)'}
                </button>
                <div className="absolute right-0 mt-1 w-32 bg-[#0f172a] border border-slate-700 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                  <div onClick={() => setCurrencyFormat('default')} className="px-3 py-2 text-xs cursor-pointer hover:bg-slate-800 text-slate-200">₹ Exact Amount</div>
                  <div onClick={() => setCurrencyFormat('lakhs')} className="px-3 py-2 text-xs cursor-pointer hover:bg-slate-800 text-slate-200">In Lakhs (L)</div>
                  <div onClick={() => setCurrencyFormat('crores')} className="px-3 py-2 text-xs cursor-pointer hover:bg-slate-800 text-slate-200">In Crores (Cr)</div>
                </div>
              </div>

              {/* Advanced Year/Month Accordion & Search */}
              <div className="relative flex items-center bg-[#0f172a] border border-slate-700 rounded-lg shadow-lg z-40">
                 <button 
                   onClick={() => { setShowYearAccordion(!showYearAccordion); setShowSearchPopup(false); }}
                   className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-400 hover:text-blue-300 border-r border-slate-700"
                 >
                   <Calendar size={14} /> 
                   {dateRange === 'All' ? 'Year' : dateRange.substring(0, 15)}
                 </button>

                 <button 
                   onClick={() => { setShowSearchPopup(!showSearchPopup); setShowYearAccordion(false); }}
                   className="px-2 py-1.5 text-blue-400 hover:text-white transition-colors"
                   title="Search Date Range"
                 >
                   <Search size={14} />
                 </button>

                 {/* Accordion Dropdown Menu */}
                 {showYearAccordion && (
                   <div className="absolute top-full right-0 mt-1 w-48 panel-3d rounded-xl overflow-hidden shadow-2xl">
                     <div className="p-1 border-b border-slate-700/50">
                        <button onClick={() => { setDateRange('All'); setShowYearAccordion(false); setExpandedYear(null); }} className="w-full text-left px-3 py-2 text-xs text-slate-200 hover:bg-blue-500/20 rounded-lg font-semibold">
                          View All Time
                        </button>
                     </div>
                     {['2025', '2026'].map(year => (
                        <div key={year} className="border-b border-slate-700/30 last:border-0">
                           <button onClick={() => setExpandedYear(expandedYear === year ? null : year)} className="w-full flex justify-between items-center px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 font-semibold">
                             <span>{year}</span>
                             {expandedYear === year ? <ChevronUp size={12}/> : <ChevronDown size={12}/>}
                           </button>
                           {expandedYear === year && (
                             <div className="bg-[#020617]/50 py-1">
                                <button onClick={() => { setDateRange(year); setShowYearAccordion(false); }} className="w-full text-left px-6 py-1.5 text-[10px] text-blue-400 hover:text-white font-semibold">
                                  Entire {year}
                                </button>
                                {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map(month => (
                                  <button key={month} onClick={() => { setDateRange(`${month} ${year}`); setShowYearAccordion(false); }} className="w-full text-left px-6 py-1.5 text-[10px] text-slate-400 hover:text-white hover:bg-slate-800">
                                    {month} {year}
                                  </button>
                                ))}
                             </div>
                           )}
                        </div>
                     ))}
                   </div>
                 )}

                 {/* Smart Search Popup */}
                 {showSearchPopup && (
                   <div className="absolute top-full right-0 mt-2 w-64 panel-3d rounded-xl p-3 shadow-2xl">
                     <label className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-2 block">Search Any Time Range</label>
                     <input 
                        type="text" 
                        placeholder="e.g. May 2025 to Feb 2026" 
                        value={tempSearchInput}
                        onChange={(e) => setTempSearchInput(e.target.value)}
                        onKeyDown={(e) => { if(e.key === 'Enter') { setDateRange(tempSearchInput || 'All'); setShowSearchPopup(false); } }}
                        className="w-full bg-[#020617] border border-slate-700 rounded p-2 text-xs text-white focus:border-blue-500 outline-none mb-3 shadow-inner"
                     />
                     <button onClick={() => { setDateRange(tempSearchInput || 'All'); setShowSearchPopup(false); }} className="w-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold py-2 rounded shadow-[0_0_10px_rgba(37,99,235,0.5)]">
                        Apply Search
                     </button>
                   </div>
                 )}
              </div>
            </>
          )}
        </div>
      </header>

      {/* --- DASHBOARD BODY --- */}
      {viewMode === 'overview' ? (
        <div className="flex-1 flex flex-col min-h-0 gap-3">
          
          {/* Top KPI Cards */}
          <div className="flex-shrink-0 grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
            <div 
              className="panel-3d p-3 rounded-xl border-l-2 border-l-emerald-500 cursor-pointer hover:bg-emerald-900/10 transition-all group relative overflow-hidden"
              onClick={() => { setViewMode('villas'); setSearchTerm(''); }}
            >
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-semibold text-slate-400 group-hover:text-emerald-400 transition-colors">Total Inflow</span>
                <TrendingUp size={14} className="text-emerald-500" />
              </div>
              <div className="text-lg md:text-2xl font-bold text-emerald-400 font-mono drop-shadow-[0_0_8px_rgba(16,185,129,0.4)]">
                {formatCurrency(processedData.inflow)}
              </div>
              <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                 <span className="bg-emerald-500/20 text-emerald-300 text-[9px] px-2 py-0.5 rounded-full font-bold">VILLAS ↗</span>
              </div>
            </div>

            <div 
              className={`panel-3d p-3 rounded-xl border-l-2 border-l-rose-500 cursor-pointer hover:bg-rose-900/10 transition-all ${logTypeFilter === 'Expense' ? 'bg-rose-900/20 ring-1 ring-rose-500/50' : ''}`}
              onClick={() => { setLogTypeFilter(logTypeFilter === 'Expense' ? 'All' : 'Expense'); setLogCategoryFilter('All'); }}
            >
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-semibold text-slate-400">Total Outflow</span>
                <TrendingDown size={14} className="text-rose-500" />
              </div>
              <div className="text-lg md:text-2xl font-bold text-rose-400 font-mono drop-shadow-[0_0_8px_rgba(244,63,94,0.4)]">
                {formatCurrency(processedData.outflow)}
              </div>
            </div>

            <div 
              className={`panel-3d p-3 rounded-xl border-l-2 border-l-amber-500 cursor-pointer hover:bg-amber-900/10 transition-all ${logTypeFilter === 'Refund' ? 'bg-amber-900/20 ring-1 ring-amber-500/50' : ''}`}
              onClick={() => { setLogTypeFilter(logTypeFilter === 'Refund' ? 'All' : 'Refund'); setLogCategoryFilter('All'); }}
            >
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-semibold text-slate-400">Refunds Issued</span>
                <Crosshair size={14} className="text-amber-500" />
              </div>
              <div className="text-lg md:text-2xl font-bold text-amber-400 font-mono drop-shadow-[0_0_8px_rgba(245,158,11,0.4)]">
                {formatCurrency(processedData.refunds)}
              </div>
            </div>

            <div 
              className="panel-3d p-3 rounded-xl border-l-2 border-l-blue-500 cursor-pointer hover:bg-blue-900/10 transition-all"
              onClick={() => { setLogTypeFilter('All'); setLogCategoryFilter('All'); setSearchTerm(''); }}
            >
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-semibold text-slate-400">Net Position <span className="text-[9px] text-blue-500">(Reset Filters)</span></span>
                <Database size={14} className="text-blue-400" />
              </div>
              <div className={`text-lg md:text-2xl font-bold font-mono ${processedData.netPosition >= 0 ? 'text-white' : 'text-rose-500'}`}>
                {processedData.netPosition < 0 ? '-' : ''}{formatCurrency(Math.abs(processedData.netPosition))}
              </div>
            </div>
          </div>

          {/* AI Insights Bar */}
          <div className="flex-shrink-0 bg-gradient-to-r from-blue-900/30 via-indigo-900/20 to-purple-900/30 border border-blue-500/20 rounded-xl p-2.5 flex justify-between items-center shadow-[0_0_15px_rgba(59,130,246,0.1)]">
             <div className="flex items-center gap-2">
                <Zap size={14} className="text-amber-400 animate-pulse" />
                <span className="text-[10px] font-bold text-blue-300 tracking-widest uppercase hidden md:inline-block">AI Insights</span>
             </div>
             
             <div className="flex gap-4 md:gap-8 divide-x divide-white/10">
                <div className="pl-4 md:pl-8">
                   <div className="text-[9px] text-slate-400 font-medium">Avg Cost Per Sale (CAC)</div>
                   <div className="text-xs md:text-sm font-bold text-rose-300">{formatCurrency(processedData.costPerVilla)}</div>
                </div>
                <div className="pl-4 md:pl-8 hidden sm:block">
                   <div className="text-[9px] text-slate-400 font-medium">Est. Monthly Burn Rate</div>
                   <div className="text-xs md:text-sm font-bold text-amber-300">{formatCurrency(processedData.avgMonthlyBurn)}</div>
                </div>
                <div className="pl-4 md:pl-8">
                   <div className="text-[9px] text-slate-400 font-medium">Estimated Runway</div>
                   <div className={`text-xs md:text-sm font-bold ${Number(processedData.cashRunway) > 6 ? 'text-emerald-400' : 'text-rose-500'}`}>
                      {Number(processedData.cashRunway) > 0 ? `${processedData.cashRunway} Months` : 'Critical'}
                   </div>
                </div>
             </div>
          </div>

          {/* Middle Analytics */}
          <div className="flex-shrink-0 grid grid-cols-1 md:grid-cols-12 gap-3 h-[28vh]">
             <div className="md:col-span-5 panel-3d rounded-xl p-3 flex flex-col overflow-hidden">
               <h3 className="text-xs font-semibold text-slate-300 flex items-center gap-2 mb-3">
                 <Target size={14} className="text-blue-500" /> Category Breakdown
               </h3>
               <div className="flex-1 overflow-y-auto custom-scroll space-y-2.5 pr-2">
                 {processedData.breakdownData.map((item) => {
                   const maxVal = processedData.breakdownData[0]?.value || 1;
                   const isActive = logCategoryFilter === item.name;
                   const percent = (item.value / maxVal) * 100;
                   return (
                     <div 
                        key={item.name} 
                        onClick={() => { setLogCategoryFilter(isActive ? 'All' : item.name); setLogTypeFilter('All'); }}
                        className={`cursor-pointer group relative`}
                     >
                       <div className="flex justify-between text-[10px] md:text-xs mb-1">
                         <span className={`${isActive ? 'text-blue-400 font-bold' : 'text-slate-300 group-hover:text-white'} transition-colors`}>{item.name}</span>
                         <span className="font-mono text-slate-400 group-hover:text-blue-300">{formatCurrency(item.value)}</span>
                       </div>
                       <div className="h-1.5 w-full bg-[#020617] rounded-full overflow-hidden shadow-inner">
                         <div className={`h-full rounded-full transition-all duration-1000 ${isActive ? 'bg-blue-400 shadow-[0_0_8px_rgba(96,165,250,0.8)]' : 'bg-slate-600 group-hover:bg-blue-500'}`} style={{ width: `${percent}%` }}></div>
                       </div>
                     </div>
                   );
                 })}
               </div>
             </div>

             <div className="md:col-span-4 panel-3d rounded-xl p-3 flex flex-col items-center justify-center relative">
                <h3 className="text-xs font-semibold text-slate-300 absolute top-3 left-3 flex items-center gap-2">
                  <PieChartIcon size={14} className="text-purple-400" /> Distribution
                </h3>
                
                <div className="w-full h-full max-h-[160px] relative mt-4">
                   <div className="absolute inset-0 flex flex-col items-center justify-center z-0 pointer-events-none">
                       <span className="text-[10px] text-slate-500 uppercase tracking-widest">Items</span>
                       <span className="text-xl font-bold text-white font-mono drop-shadow-[0_0_5px_rgba(255,255,255,0.5)]">{processedData.breakdownData.length}</span>
                   </div>
                   <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                         <Pie data={processedData.breakdownData.slice(0, 6)} dataKey="value" innerRadius="70%" outerRadius="90%" paddingAngle={4} stroke="none">
                            {processedData.breakdownData.slice(0, 6).map((entry, index) => (
                               <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} style={{ filter: `drop-shadow(0px 0px 6px ${COLORS[index % COLORS.length]})`, cursor: 'pointer' }} onClick={() => { setLogCategoryFilter(entry.name); setLogTypeFilter('All'); }} />
                            ))}
                         </Pie>
                         <RechartsTooltip formatter={(val) => formatCurrency(val)} contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px', color: '#fff' }} itemStyle={{ color: '#fff' }} />
                      </PieChart>
                   </ResponsiveContainer>
                </div>
             </div>

             <div className="md:col-span-3 panel-3d rounded-xl p-3 flex flex-col overflow-hidden">
                <h3 className="text-xs font-semibold text-slate-300 flex items-center gap-2 mb-3">
                  <Activity size={14} className="text-rose-400" /> Top Transactions
                </h3>
                <div className="flex-1 overflow-y-auto custom-scroll space-y-2 pr-1">
                   {processedData.transactions.slice(0, 8).map((trx, idx) => (
                      <div key={idx} className="flex justify-between items-center p-2 bg-[#020617]/50 rounded-lg border border-white/5 hover:border-white/10 transition-colors">
                         <div className="flex flex-col overflow-hidden pr-2">
                           <span className="text-[10px] font-medium text-slate-200 truncate" title={trx.payeeName}>{trx.payeeName}</span>
                           <span className="text-[8px] text-slate-500 uppercase">{trx.category}</span>
                         </div>
                         <span className={`font-mono text-[10px] font-bold ${trx.type === 'Revenue' ? 'text-emerald-400' : trx.type === 'Refund' ? 'text-amber-400' : 'text-slate-300'}`}>
                           {formatCurrency(trx.currentAmount)}
                         </span>
                      </div>
                   ))}
                </div>
             </div>
          </div>

          {/* Detailed Transaction Log */}
          <div className="panel-3d flex-1 rounded-xl flex flex-col overflow-hidden min-h-0">
             <div className="p-3 border-b border-slate-700/50 flex justify-between items-center bg-[#020617]/30">
               <h3 className="text-xs font-semibold text-slate-200 flex items-center gap-2">
                  <Database size={14} className="text-blue-500" /> Detailed Transaction Log
                  {(logTypeFilter !== 'All' || logCategoryFilter !== 'All') && (
                     <span className="ml-2 text-[9px] bg-blue-900/30 text-blue-300 px-2 py-0.5 rounded-full border border-blue-500/30 hidden md:inline-block">
                        Active Filter: {logCategoryFilter !== 'All' ? logCategoryFilter : logTypeFilter}
                     </span>
                  )}
               </h3>
               <div className="relative w-48 md:w-64">
                 <Search size={14} className="absolute left-3 top-2 text-slate-400" />
                 <input type="text" placeholder="Search payee or category..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                   className="w-full pl-9 pr-3 py-1.5 bg-[#0f172a] border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500 shadow-inner placeholder:text-slate-500" />
               </div>
             </div>
             
             <div className="flex-1 overflow-auto custom-scroll">
               <table className="w-full text-left border-collapse whitespace-nowrap">
                 <thead className="bg-[#0f172a]/90 sticky top-0 backdrop-blur-md z-10 border-b border-slate-700/50">
                   <tr>
                     <th className="px-4 py-2.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Date/Period</th>
                     <th className="px-4 py-2.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Type</th>
                     <th className="px-4 py-2.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Category</th>
                     <th className="px-4 py-2.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Client / Payee Name</th>
                     <th className="px-4 py-2.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-right">Amount</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-800/50 bg-[#0b1120]/30">
                   {processedData.transactions.map((trx, index) => (
                     <tr key={index} className="hover:bg-white/5 transition-colors">
                       <td className="px-4 py-2 text-[10px] text-slate-400">{new Date(trx.date).toLocaleString('en-US',{month:'short', year:'numeric'})}</td>
                       <td className="px-4 py-2 text-[10px]">
                          <span className={`px-2 py-0.5 rounded font-semibold ${trx.type === 'Revenue' ? 'bg-emerald-900/30 text-emerald-400 border border-emerald-500/20' : trx.type === 'Refund' ? 'bg-amber-900/30 text-amber-400 border border-amber-500/20' : 'bg-slate-800 text-slate-300 border border-slate-600'}`}>
                            {trx.type}
                          </span>
                       </td>
                       <td className="px-4 py-2 text-xs text-slate-400">{trx.category}</td>
                       <td className="px-4 py-2 text-xs font-medium text-slate-200">{trx.payeeName}</td>
                       <td className={`px-4 py-2 text-xs font-mono font-bold text-right ${trx.type === 'Revenue' ? 'text-emerald-400' : trx.type === 'Refund' ? 'text-amber-400' : 'text-slate-100'}`}>
                         {formatCurrency(trx.currentAmount)}
                       </td>
                     </tr>
                   ))}
                 </tbody>
               </table>
             </div>
          </div>
        </div>
      ) : (
        /* --- VILLA CLIENT LEDGERS VIEW --- */
        <div className="flex-1 flex flex-col min-h-0 gap-3 animate-in fade-in duration-300">
          
          {/* Top Master Comparison Bar */}
          <div className="flex-shrink-0 bg-gradient-to-r from-blue-900/30 via-indigo-900/20 to-slate-900/50 border border-blue-500/20 rounded-xl p-3 flex justify-between items-center shadow-lg">
             <div className="flex items-center gap-6">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                   <Building2 size={20} />
                </div>
                <div className="flex gap-6 text-xs divide-x divide-slate-700/50">
                   <div className="pl-0">
                      <span className="text-[9px] uppercase tracking-wider text-slate-400 font-medium block mb-1">Main Ledger Inflow</span>
                      <strong className="text-slate-100 text-base font-bold font-mono">{formatCurrency(villaStats.masterLedgerInflow)}</strong>
                   </div>
                   <div className="pl-6">
                      <span className="text-[9px] uppercase tracking-wider text-slate-400 font-medium block mb-1">Villa Receipts Match</span>
                      <strong className="text-emerald-400 text-base font-bold font-mono">{formatCurrency(villaStats.totalCollected)}</strong>
                   </div>
                </div>
             </div>
             <div className="text-right bg-blue-950/40 px-4 py-2 rounded-lg border border-blue-500/20">
                 <span className="text-[9px] uppercase tracking-wider text-blue-300 block font-medium mb-1">Collection Progress</span>
                 <span className="text-base font-extrabold text-blue-400">{villaStats.collectionProgress}%</span>
             </div>
          </div>

          <div className="flex-shrink-0 grid grid-cols-2 md:grid-cols-6 gap-2">
             <div className="panel-3d rounded-xl p-3 text-center shadow-lg border-t-2 border-t-blue-500">
                <div className="text-white font-mono font-bold text-lg md:text-xl">{villaStats.totalUnits}</div>
                <div className="text-[9px] uppercase tracking-widest text-slate-400 mt-1">Total Units</div>
             </div>
             <div className="panel-3d rounded-xl p-3 text-center shadow-lg border-t-2 border-t-emerald-500">
                <div className="text-emerald-400 font-mono font-bold text-lg md:text-xl">{villaStats.soldOutUnits}</div>
                <div className="text-[9px] uppercase tracking-widest text-slate-400 mt-1">Sold Units</div>
             </div>
             <div className="panel-3d rounded-xl p-3 text-center shadow-lg">
                <div className="text-blue-300 font-mono font-bold text-sm md:text-md mt-1">{formatCurrency(villaStats.totalAts)}</div>
                <div className="text-[9px] uppercase tracking-widest text-slate-400 mt-1">Total ATS Value</div>
             </div>
             <div className="panel-3d rounded-xl p-3 text-center shadow-lg border-b-2 border-b-emerald-500">
                <div className="text-emerald-400 font-mono font-bold text-sm md:text-md mt-1">{formatCurrency(villaStats.totalCollected)}</div>
                <div className="text-[9px] uppercase tracking-widest text-slate-400 mt-1">Total Received</div>
             </div>
             <div className="panel-3d rounded-xl p-3 text-center shadow-lg border-b-2 border-b-rose-500">
                <div className="text-rose-400 font-mono font-bold text-sm md:text-md mt-1">{formatCurrency(villaStats.totalBalance)}</div>
                <div className="text-[9px] uppercase tracking-widest text-slate-400 mt-1">Total Balance Due</div>
             </div>
          </div>

          <div className="panel-3d flex-1 rounded-xl flex flex-col overflow-hidden min-h-0">
             <div className="p-3 border-b border-slate-700/50 flex justify-between items-center bg-[#020617]/30">
               <h3 className="text-xs font-semibold text-slate-200 flex items-center gap-2">
                  <Building2 size={14} className="text-emerald-400" /> Client Inventory & Balances
               </h3>
               <div className="relative w-48 md:w-64">
                 <Search size={14} className="absolute left-3 top-2 text-slate-400" />
                 <input type="text" placeholder="Search Client or Villa..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                   className="w-full pl-9 pr-3 py-1.5 bg-[#0f172a] border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500 shadow-inner" />
               </div>
             </div>
             
             <div className="flex-1 overflow-auto custom-scroll">
               <table className="w-full text-left border-collapse whitespace-nowrap">
                 <thead className="bg-[#0f172a]/90 sticky top-0 backdrop-blur-md z-10 border-b border-slate-700/50">
                    <tr>
                       <th className="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Villa</th>
                       <th className="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Client Name</th>
                       <th className="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-right">ATS Value</th>
                       <th className="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-right">Received</th>
                       <th className="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-right">Balance</th>
                       <th className="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">Status</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-800/50 bg-[#0b1120]/30">
                    {filteredVillas.map((item, index) => {
                       let displayAmount = item.amount;
                       let ratio = 1;
                       if(dateRange !== 'All' && processedData.inflow > 0 && item.amount > 0) {
                           ratio = item.amount / processedData.inflow;
                           if(ratio > 1) ratio = 1;
                           displayAmount = processedData.inflow * ratio;
                       }
                       const percent = item.atsValue > 0 ? Math.round((displayAmount / item.atsValue) * 100) : 0;
                       
                       return (
                          <tr key={index} className="hover:bg-white/5 transition-colors">
                             <td className="px-4 py-2.5 text-xs font-bold text-emerald-400">{item.villa}</td>
                             <td className="px-4 py-2.5 text-xs text-slate-200 font-medium">{item.client}</td>
                             <td className="px-4 py-2.5 text-xs font-mono text-slate-400 text-right">{formatCurrency(item.atsValue)}</td>
                             <td className="px-4 py-2.5 text-xs font-mono font-bold text-emerald-400 text-right">{formatCurrency(displayAmount)}</td>
                             <td className="px-4 py-2.5 text-xs font-mono font-bold text-rose-400 text-right">{formatCurrency(item.balance)}</td>
                             <td className="px-4 py-2.5 text-center">
                                <span className={`inline-block px-3 py-1 text-[10px] font-bold rounded-full border ${item.status === 'Sold Out' || item.status === 'Sold' ? 'bg-emerald-900/30 text-emerald-400 border-emerald-500/30' : 'bg-slate-800 text-slate-400 border-slate-600'}`}>
                                   {item.status} ({percent}%)
                                </span>
                             </td>
                          </tr>
                       )
                    })}
                 </tbody>
               </table>
             </div>
          </div>
        </div>
      )}
    </div>
  );
}